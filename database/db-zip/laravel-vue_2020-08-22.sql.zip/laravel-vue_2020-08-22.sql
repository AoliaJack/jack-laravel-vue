# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.01 (MySQL 5.5.5-10.4.13-MariaDB)
# Database: laravel-vue
# Generation Time: 2020-08-22 13:47:19 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table failed_jobs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table features
# ------------------------------------------------------------

DROP TABLE IF EXISTS `features`;

CREATE TABLE `features` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fdesc` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pricings_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `features` WRITE;
/*!40000 ALTER TABLE `features` DISABLE KEYS */;

INSERT INTO `features` (`id`, `fname`, `fdesc`, `pricings_id`, `created_at`, `updated_at`)
VALUES
	(1,'0.5X','RESOURCE POWER',1,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(2,'500 MB','Disk Space',1,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(3,'Unlimited','Bandwidth',1,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(4,'Unlimited','Databases',1,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(5,'1','Domain',1,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(6,'Instant','Backup',1,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(7,'Unlimited SSL','Gratis Selamanya',1,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(8,'1X','RESOURCE POWER',2,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(9,'Unlimited','Disk Space',2,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(10,'Unlimited','Bandwidth',2,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(11,'Unlimited','POP 3 Email',2,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(12,'Unlimited','Databases',2,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(13,'10','Addon Domains',2,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(14,'Instant','Backup',2,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(15,'Domain Gratis','Selamanya',2,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(16,'Unlimited SSL','Gratis Selamanya',2,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(17,'2X','RESOURCE POWER',3,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(18,'Unlimited','Disk Space',3,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(19,'Unlimited','Bandwidth',3,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(20,'Unlimited','POP3 Email',3,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(21,'Unlimited','Addon Domain',3,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(22,'Instant','Backup',3,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(23,'Domain Gratis','Selamanya',3,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(24,'Unlimited SSL','Gratis Selamanya',3,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(25,'Private','Name Server',3,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(26,'SpamAssasin','Mail Protection',3,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(27,'3X','RESOURCE POWER',4,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(28,'Unlimited','Disk Space',4,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(29,'Unlimited','Bandwidth',4,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(30,'Unlimited','POP3 Email',4,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(31,'Unlimited','Addon Domain',4,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(32,'Magic Auto','Backup & Restore',4,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(33,'Domain Gratis','Selamanya',4,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(34,'Unlimited SSL','Gratis Selamanya',4,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(35,'Private','Name Server',4,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(36,'Prioritas','Layanan Support',4,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(37,'SpamExpert','Pro Mail Protection',4,'2020-08-21 19:20:30','2020-08-21 19:20:30');

/*!40000 ALTER TABLE `features` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;

INSERT INTO `migrations` (`id`, `migration`, `batch`)
VALUES
	(1,'2014_10_12_000000_create_users_table',1),
	(2,'2014_10_12_100000_create_password_resets_table',1),
	(3,'2019_08_19_000000_create_failed_jobs_table',1),
	(4,'2020_08_21_115150_create_pricings_table',1),
	(5,'2020_08_22_010820_create_features_table',2),
	(6,'2020_08_22_014942_create_mixes_table',3),
	(7,'2020_08_22_015534_create_mixes_table',4),
	(8,'2020_08_22_020839_create_features_table',5),
	(9,'2020_08_22_030633_alter_pricing',6),
	(10,'2020_08_22_033348_alter_features',7),
	(11,'2020_08_22_033801_create_features_table',8),
	(12,'2020_08_22_070727_create_fiturs_table',9);

/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table password_resets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table pricings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pricings`;

CREATE TABLE `pricings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `price-after` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `features` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `pricings` WRITE;
/*!40000 ALTER TABLE `pricings` DISABLE KEYS */;

INSERT INTO `pricings` (`id`, `name`, `price`, `price-after`, `user`, `status`, `features`, `created_at`, `updated_at`)
VALUES
	(1,'Bayi',19900,14900,938,0,1,'2020-08-21 19:20:30','2020-08-21 19:20:30'),
	(2,'Pelajar',46900,23450,4168,0,2,'2020-08-21 20:33:46','2020-08-21 20:33:46'),
	(3,'Personal',58900,38900,10017,1,3,'2020-08-21 20:34:38','2020-08-21 20:34:38'),
	(4,'Bisnis',109900,65900,3552,0,4,'2020-08-21 20:35:26','2020-08-21 20:35:26');

/*!40000 ALTER TABLE `pricings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
